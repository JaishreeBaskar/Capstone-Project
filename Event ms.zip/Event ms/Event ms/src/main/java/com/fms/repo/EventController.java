package com.fms.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.fms.model.Event;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class EventController {

	@Autowired
	EventRepo eventrepo;
	
@GetMapping("/events")
public Flux<Event> getAllEvents(){
	return eventrepo.findAll();
	}

@GetMapping(value="event/{id}")
public Mono<Event> findEventById (@PathVariable Integer id){
	return eventrepo.findById(id);
}
	
}
