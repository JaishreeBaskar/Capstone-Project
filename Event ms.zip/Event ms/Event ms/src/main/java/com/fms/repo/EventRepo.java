package com.fms.repo;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.fms.model.Event;

import reactor.core.publisher.Mono;

@Component
@Repository
public interface EventRepo extends ReactiveCrudRepository<Event, Integer>{
	
	@Query("select * from event where EventId = 1")
	Mono<Event> findByEventId(String eventId);

}
