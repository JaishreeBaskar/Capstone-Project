package com.fms.repo;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.fms.model.Event;
import reactor.core.publisher.Flux;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

@Repository
public interface EventRepo extends ReactiveCrudRepository<Event, Integer>{

//	public Flux<Event> findAll() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//	
		// some error
//	@Query("select * from events")
//	Flux<Event> findAll(String EventId);

}
